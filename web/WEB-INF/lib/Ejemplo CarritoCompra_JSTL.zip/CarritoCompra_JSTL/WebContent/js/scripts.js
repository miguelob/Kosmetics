    function buscar(producto)
    {
        document.formulario.producto.value = producto;
        document.formulario.submit();
    }
    
    function validar()
    {
        if(document.formulario.producto.value.length == 0)
        {
            document.getElementById("error").innerHTML = "Introduzca un criterio de búsqueda";
            document.formulario.producto.select;
            return false;
        }      
    }    
    