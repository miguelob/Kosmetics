package servicios;

import dao.ProductoDAO;
import dominio.Carrito;
import dominio.Producto;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


public class CarritoServicio 
{
    private HttpServletRequest request;
    private Carrito carrito;
    
    public CarritoServicio (HttpServletRequest request)
    {
        this.request = request;
        carrito = this.getCarrito();
    }
    
    private Carrito getCarrito()
    {
        HttpSession sesion = request.getSession();
        carrito = (Carrito) sesion.getAttribute("carrito");

        if (carrito==null)
        {
            carrito = new Carrito(); 
            sesion.setAttribute("carrito", carrito);
        }
        
        return carrito;
    }
    
    public void comprar(int id) throws ClassNotFoundException, SQLException
    {
        ProductoDAO dao = ProductoDAO.getInstance();

        Producto p = null;
        p = dao.findById(id);
        
        if(p!=null)
            getCarrito().addProducto(p);
    }
    
    public void eliminar(int id)
    {
        Producto p = new Producto(id);
        getCarrito().removeProducto(p);
    }
    
    public void vaciar()
    {
        getCarrito().clear();
    }    

    /**
     * @param carrito the carrito to set
     */
    public void setCarrito(Carrito carrito) {
        this.carrito = carrito;
    }
}
