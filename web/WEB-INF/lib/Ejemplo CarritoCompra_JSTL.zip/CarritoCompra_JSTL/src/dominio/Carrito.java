
package dominio;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class Carrito 
{
    private HashMap <Producto, Integer> carrito;
    
    public Carrito ()
    {
        carrito = new HashMap <Producto, Integer>();
    }
    
    public void addProducto(Producto p)
    {
        Integer unidades = carrito.get(p);
        if(unidades!=null)
           carrito.put(p, unidades + 1);
        else
           carrito.put(p, 1);        
    }
    
    public void removeProducto(Producto p)
    {
        Integer unidades = carrito.get(p);
        if(unidades==1)
            carrito.remove(p);
        else
            carrito.put(p, unidades - 1);
    }
    
    public int getCantidades(Producto p) 
    {
        Integer unidades = carrito.get(p);
        if(unidades != null)
            return unidades;
        else
            return 0;
    }
    
    public void clear()
    {
        carrito.clear();
    }
    
    public Set<Producto> getProductos()
    {
        return carrito.keySet();
    }
    
    public Collection<Integer> getUnidades()
    {
        return carrito.values();
    }
    
    public HashMap <Producto, Integer> getMap()
    {
        return carrito;
    }    
    
    public int getSize()
    {
        return carrito.size();
    }
    
    public double getPrecioTotal()
    {
        double precioTotal = 0;
        
        for(Map.Entry<Producto, Integer> mapa : carrito.entrySet())
            precioTotal += mapa.getKey().getPrecio() *  mapa.getValue();
            
        return precioTotal;
    }    
    
}
