/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import dominio.Usuario;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class UsuarioDAO extends DAO
{
    private static String QUERY_USER = "SELECT * FROM Usuario WHERE usuario = ? AND contrasena = ?";
    
    private static UsuarioDAO dao;

    private UsuarioDAO() throws ClassNotFoundException, SQLException
    {
        super();
    }
    
    public static UsuarioDAO getInstance() throws ClassNotFoundException, SQLException
    {
        if(dao == null || !c.isValid(0) || c.isClosed())
        {
            dao = new UsuarioDAO();
            System.out.println("Debug: Nueva DAO");
        }
            
        return dao;
    }

    public void close() throws SQLException
    {
            c.close();
    }

    public boolean findByUsuario(Usuario u) throws SQLException
    {
        PreparedStatement ps = c.prepareStatement(QUERY_USER);
        ps.setString(1, u.getNombre());
        ps.setString(2, u.getContrasena());
        ResultSet rs = ps.executeQuery();

        if (rs.next())
            return true;
        else
            return false;

    }

}
