package dao;

import java.sql.*;

public abstract class DAO
{
    protected static Connection c;
            
    protected DAO() throws ClassNotFoundException, SQLException
    {
    	Class.forName("com.mysql.cj.jdbc.Driver");
        String bd = "jdbc:mysql://127.0.0.1/pat?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        c = DriverManager.getConnection(bd, "root", "");
    }
    
    public void close() throws SQLException
    {
            c.close();
    }
}
