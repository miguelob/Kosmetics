/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dao.ProductoDAO;
import dominio.Producto;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import servicios.CarritoServicio;


public class ProductoController extends HttpServlet 
{

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        String mensajeError = "";

        String vista = "/listadoProductos.jsp";
        String opcion = "";
        
        try
        {
            opcion = request.getParameter("opcion");
            int id = 0;
            if(request.getParameter("id")!=null)
                id = Integer.parseInt(request.getParameter("id")); 
            String producto = request.getParameter("producto"); 
            
            Collection<Producto> productos = null;
            
            
            if(opcion!=null)
            {
                if(opcion.equals("comprar"))
                    new CarritoServicio(request).comprar(id);
                else if(opcion.equals("eliminar"))
                    new CarritoServicio(request).eliminar(id);
                else if(opcion.equals("vaciar"))
                    new CarritoServicio(request).vaciar();
                else if(opcion.equals("finalizar"))
                    vista = "/comprar.jsp";                
            }

            Collection<String> cookiesOrdenadas = (Collection<String>)request.getSession().getAttribute("cookiesSet");
            if(cookiesOrdenadas==null){
                Cookie cookies[] = request.getCookies();
                cookiesOrdenadas = new TreeSet<String>();
                if(cookies!=null)
                {
                    for(Cookie c:cookies)            
                    {
                        if(c.getName().equals("productosBuscados"))
                        {
                            String productosBuscados = c.getValue();
                            String palabras[] = productosBuscados.split(":");
                            for(String palabra:palabras)
                                cookiesOrdenadas.add(palabra);
                        }
                    }
                    request.getSession().setAttribute("cookiesSet", cookiesOrdenadas);
                }
            }            
            
            if(producto != null){
                productos = ProductoDAO.getInstance().findProductosByName(producto);                                    
                
                cookiesOrdenadas.add(producto.toLowerCase());

                StringBuffer cookieSB = new StringBuffer();
                for(String busqueda:cookiesOrdenadas)
                    cookieSB.append(busqueda + ":");

                cookieSB.deleteCharAt(cookieSB.length()-1);

                Cookie cookieBusqueda = new Cookie("productosBuscados", cookieSB.toString());

                cookieBusqueda.setHttpOnly(true);
                cookieBusqueda.setPath("/");
                cookieBusqueda.setMaxAge(Integer.MAX_VALUE);
                response.addCookie(cookieBusqueda);

                
            }
            else
                productos = ProductoDAO.getInstance().findAllProductos();

            request.setAttribute("productos", productos);
            
        }
        catch(NumberFormatException ex)
        {
            Logger.getLogger(ProductoController.class.getName()).log(Level.SEVERE, null, ex);
            mensajeError = "Id de producto no válido";
            request.setAttribute("mensajeError", mensajeError);
            vista = "/error.jsp";
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(ProductoController.class.getName()).log(Level.SEVERE, null, ex);
            mensajeError = "No se pudo iniciar la conexión con la Base de Datos";
            request.setAttribute("mensajeError", mensajeError);
            vista = "/error.jsp";
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(ProductoController.class.getName()).log(Level.SEVERE, null, ex);
            mensajeError = "Error de Base de Datos";
            request.setAttribute("mensajeError", mensajeError);
            vista = "/error.jsp";
        }
        
        RequestDispatcher rd = request.getRequestDispatcher(vista);
        rd.forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
